from ..client import WebSocketClient

class WebSocketFutOptClient(WebSocketClient):
    pass
