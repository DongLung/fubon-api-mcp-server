from urllib.parse import urlencode
import requests


class FugleAPIError(Exception):
    """Fugle API 錯誤，包含 debug 資訊"""
    def __init__(self, message, url=None, status_code=None, params=None, response_text=None):
        self.message = message
        self.url = url
        self.status_code = status_code
        self.params = params
        self.response_text = response_text
        
        # 建構完整的錯誤訊息
        error_parts = [f"[Fugle API Error] {message}"]
        if url:
            error_parts.append(f"URL: {url}")
        if status_code:
            error_parts.append(f"Status: {status_code}")
        if params:
            error_parts.append(f"Params: {params}")
        if response_text:
            error_parts.append(f"Response: {response_text[:200]}...")
        
        super().__init__('\n'.join(error_parts))


class BaseRest(object):
    def __init__(self, **config):
        self.config = config

    def request(self, path, **params):
        baseUrl = self.config['base_url']
        headers = {}
        if self.config.get('api_key'):
            headers['X-API-KEY'] = self.config['api_key']
        if self.config.get('bearer_token'):
            headers['Authorization'] = f"Bearer {self.config['bearer_token']}"
        if self.config.get('sdk_token'):
            headers['X-SDK-TOKEN'] = self.config['sdk_token']

        endpoint = path if (path.startswith('/')) else '/' + path

        if len(params) == 0:
            query = ''
        else:
            query = '?' + urlencode(params)

        url = baseUrl + endpoint + query
        
        try:
            response = requests.get(url, headers=headers)
            
            # 檢查 HTTP 錯誤狀態
            if response.status_code >= 400:
                error_msg = f"HTTP {response.status_code}"
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        error_msg = error_data['message']
                except:
                    pass
                
                raise FugleAPIError(
                    error_msg,
                    url=url,
                    status_code=response.status_code,
                    params=params,
                    response_text=response.text
                )
            
            return response.json()
            
        except ValueError as e:
            raise FugleAPIError(
                "Failed to parse JSON response",
                url=url,
                status_code=response.status_code,
                params=params,
                response_text=response.text
            )
            
        except requests.exceptions.RequestException as e:
            raise FugleAPIError(
                f"{type(e).__name__}: {str(e)}",
                url=url,
                params=params
            )
